export interface segmentsTab {
    header?: string;
    content?: string;
    icon?:string;
    }