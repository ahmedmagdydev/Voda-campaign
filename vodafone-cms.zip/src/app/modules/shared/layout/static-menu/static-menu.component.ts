import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-static-menu',
  templateUrl: './static-menu.component.html',
  styleUrls: ['./static-menu.component.css']
})
export class StaticMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
