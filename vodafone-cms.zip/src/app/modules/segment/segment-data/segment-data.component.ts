import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-segment-data',
  templateUrl: './segment-data.component.html',
  styleUrls: ['./segment-data.component.css']
})
export class SegmentDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
